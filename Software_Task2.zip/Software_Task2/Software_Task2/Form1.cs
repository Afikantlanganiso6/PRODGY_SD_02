﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Task2
{
    public partial class Form1 : Form
    {
        private int targetNumber;
        private int attempts;

        public Form1()
        {
            InitializeComponent();
            StartNewGame();
        }

        private void StartNewGame()
        {
            Random random = new Random();
            targetNumber = random.Next(1, 101);
            attempts = 0;
            lblFeedback.Text = "";
            lblAttempts.Text = "Attempts: 0";
            txtGuess.Text = "";
            txtGuess.Focus();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int guess;

            if (int.TryParse(txtGuess.Text, out guess))
            {
                attempts++;
                lblAttempts.Text = $"Attempts: {attempts}";

                if (guess < targetNumber)
                {
                    lblFeedback.Text = "Too low! Try again.";
                }
                else if (guess > targetNumber)
                {
                    lblFeedback.Text = "Too high! Try again.";
                }
                else
                {
                    lblFeedback.Text = $"Congratulations! You've guessed the correct number: {targetNumber}. It took you {attempts} attempts.";
                }
            }
            else
            {
                lblFeedback.Text = "Please enter a valid number.";
            }

            txtGuess.SelectAll();
            txtGuess.Focus();
        }
    }
}
